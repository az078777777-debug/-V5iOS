import SwiftUI

@main
struct V5iOSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
