import SwiftUI

struct ContentView: View {
    @State private var showFolderPicker = false
    @State private var scanResult: GameScanResult?
    private let report = DeviceProbe.current()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    deviceCard
                    gameDataCard
                    roadmapCard
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showFolderPicker) {
            FolderPicker { url in
                scanResult = GameFolderScanner.scan(url: url)
                showFolderPicker = false
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("V5iOS")
                .font(.system(size: 38, weight: .black, design: .rounded))
            Text("Experimental GTA V compatibility launcher for iOS")
                .foregroundColor(.secondary)
            Text("v0.1 • Probe & Data Scanner")
                .font(.caption.monospaced())
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var deviceCard: some View {
        card(title: "DEVICE PROBE") {
            row("Model", report.modelIdentifier)
            row("iOS", report.systemVersion)
            row("RAM", String(format: "%.2f GB", report.physicalMemoryGB))
            row("Metal", report.metalAvailable ? "Available" : "Unavailable")
            row("GPU", report.metalDeviceName)
            if let workingSet = report.recommendedMaxWorkingSetGB {
                row("GPU working set", String(format: "%.2f GB", workingSet))
            }
            row("Thermal", report.thermalState)
        }
    }

    private var gameDataCard: some View {
        card(title: "GAME DATA") {
            Text("Choose a GTA V data folder that you legally own. V5iOS does not include or download Rockstar assets.")
                .font(.subheadline)
                .foregroundColor(.secondary)

            Button {
                showFolderPicker = true
            } label: {
                Label("Choose GTA V Folder", systemImage: "folder.badge.plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)

            if let result = scanResult {
                Divider()
                row("Folder", result.rootName)
                row("Accessible", result.accessible ? "Yes" : "No")
                row("Top-level items", "\(result.topLevelEntries)")
                row("Top-level file size", String(format: "%.2f GB", result.estimatedTopLevelSizeGB))
                row("Marker hits", "\(result.markerHits.count)/\(result.markerHits.count + result.missingMarkers.count)")

                if !result.markerHits.isEmpty {
                    Text("Found")
                        .font(.caption.bold())
                    ForEach(result.markerHits, id: \.self) { item in
                        Label(item, systemImage: "checkmark.circle.fill")
                            .font(.caption.monospaced())
                    }
                }

                if !result.notes.isEmpty {
                    ForEach(result.notes, id: \.self) { note in
                        Text(note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
    }

    private var roadmapCard: some View {
        card(title: "NEXT ENGINEERING GATE") {
            Label("MoltenVK Vulkan probe", systemImage: "1.circle.fill")
            Label("DXVK-native compatibility experiment", systemImage: "2.circle.fill")
            Label("Android ARM64 runtime ABI research", systemImage: "3.circle.fill")
            Label("First rendered frame", systemImage: "4.circle.fill")
            Text("The launcher is deliberately separate from the runtime. If the runtime route fails, we can replace it without rewriting the UI and file-management layer.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }

    private func card<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.caption.bold())
                .foregroundColor(.secondary)
            content()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func row(_ key: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(key)
                .foregroundColor(.secondary)
            Spacer(minLength: 20)
            Text(value)
                .multilineTextAlignment(.trailing)
                .font(.system(.body, design: .monospaced))
        }
    }
}
