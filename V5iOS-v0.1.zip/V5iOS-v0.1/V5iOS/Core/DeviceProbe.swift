import Foundation
import Metal
import UIKit

struct DeviceReport {
    let modelIdentifier: String
    let systemVersion: String
    let physicalMemoryGB: Double
    let metalAvailable: Bool
    let metalDeviceName: String
    let recommendedMaxWorkingSetGB: Double?
    let thermalState: String
}

enum DeviceProbe {
    static func current() -> DeviceReport {
        let device = MTLCreateSystemDefaultDevice()
        let recommended: Double?
        if #available(iOS 16.0, *), let device {
            recommended = Double(device.recommendedMaxWorkingSetSize) / 1_073_741_824.0
        } else {
            recommended = nil
        }

        return DeviceReport(
            modelIdentifier: modelIdentifier(),
            systemVersion: UIDevice.current.systemVersion,
            physicalMemoryGB: Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824.0,
            metalAvailable: device != nil,
            metalDeviceName: device?.name ?? "Unavailable",
            recommendedMaxWorkingSetGB: recommended,
            thermalState: thermalStateName(ProcessInfo.processInfo.thermalState)
        )
    }

    private static func modelIdentifier() -> String {
        var systemInfo = utsname()
        uname(&systemInfo)
        return withUnsafePointer(to: &systemInfo.machine) { ptr in
            ptr.withMemoryRebound(to: CChar.self, capacity: 1) {
                String(cString: $0)
            }
        }
    }

    private static func thermalStateName(_ state: ProcessInfo.ThermalState) -> String {
        switch state {
        case .nominal: return "Nominal"
        case .fair: return "Fair"
        case .serious: return "Serious"
        case .critical: return "Critical"
        @unknown default: return "Unknown"
        }
    }
}
