import Foundation

struct GameScanResult {
    let rootName: String
    let accessible: Bool
    let markerHits: [String]
    let missingMarkers: [String]
    let topLevelEntries: Int
    let estimatedTopLevelSizeGB: Double
    let notes: [String]
}

enum GameFolderScanner {
    // These are only data-layout markers. No Rockstar files are bundled by V5iOS.
    private static let markers = [
        "x64a.rpf",
        "x64b.rpf",
        "x64c.rpf",
        "update/update.rpf"
    ]

    static func scan(url: URL) -> GameScanResult {
        let didAccess = url.startAccessingSecurityScopedResource()
        defer {
            if didAccess { url.stopAccessingSecurityScopedResource() }
        }

        var isDirectory: ObjCBool = false
        let exists = FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory)
        guard exists, isDirectory.boolValue else {
            return GameScanResult(
                rootName: url.lastPathComponent,
                accessible: false,
                markerHits: [],
                missingMarkers: markers,
                topLevelEntries: 0,
                estimatedTopLevelSizeGB: 0,
                notes: ["The selected URL is not an accessible directory."]
            )
        }

        var hits: [String] = []
        for marker in markers {
            let markerURL = url.appendingPathComponent(marker)
            if FileManager.default.fileExists(atPath: markerURL.path) {
                hits.append(marker)
            }
        }

        let entries = (try? FileManager.default.contentsOfDirectory(
            at: url,
            includingPropertiesForKeys: [.fileSizeKey, .isRegularFileKey],
            options: [.skipsHiddenFiles]
        )) ?? []

        var bytes: Int64 = 0
        for entry in entries {
            guard let values = try? entry.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey]),
                  values.isRegularFile == true,
                  let size = values.fileSize else { continue }
            bytes += Int64(size)
        }

        var notes: [String] = []
        if hits.count < markers.count {
            notes.append("This does not prove the data is invalid; Android-native GTA V runtimes can use a specific data layout/version.")
        }
        notes.append("V5iOS v0.1 reads metadata only. It does not modify game files.")

        return GameScanResult(
            rootName: url.lastPathComponent,
            accessible: true,
            markerHits: hits,
            missingMarkers: markers.filter { !hits.contains($0) },
            topLevelEntries: entries.count,
            estimatedTopLevelSizeGB: Double(bytes) / 1_073_741_824.0,
            notes: notes
        )
    }
}
