# V5iOS v0.1

Experimental iOS compatibility-launcher scaffold for studying whether a legally owned GTA V data set can be used with an iOS-native compatibility runtime.

## What works in v0.1

- SwiftUI launcher shell.
- Metal/GPU availability probe.
- Device model, iOS version, physical RAM, recommended Metal working set and thermal state.
- Folder picker using the iOS document picker.
- Read-only GTA V data-layout marker scan.
- No Rockstar/Take-Two assets, executables, keys, DRM bypasses or game files are included.

## What does NOT work yet

- GTA V does not launch in v0.1.
- MoltenVK is not linked yet.
- DXVK is not linked yet.
- Android ARM64 ELF runtime loading is not implemented.

## Build

Open `V5iOS.xcodeproj` in a current Xcode release, select an iPhone target, set your signing team if needed, and build.

For sideloading workflows, the included GitHub Actions job can create an **unsigned** IPA-shaped archive. It must still be signed by a valid signing method before iOS will launch it.

## Engineering plan

1. v0.1 — device + filesystem probe (this package)
2. v0.2 — MoltenVK linked; create Vulkan instance/device/surface test
3. v0.3 — DXVK-native proof of concept with a minimal D3D11 sample
4. v0.4 — investigate Android ARM64 ELF ABI/shims and required SDL/platform symbols
5. v0.5 — attempt first engine initialization using only user-supplied compatible runtime/data

## Legal / scope

V5iOS is a compatibility research scaffold. Do not distribute copyrighted GTA V assets or circumvent DRM. Use only files you are authorized to use.
