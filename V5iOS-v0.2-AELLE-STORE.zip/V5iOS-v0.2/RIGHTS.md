# V5iOS Rights Notice

© 2026 Ali Tahseen. All rights reserved.

The original V5iOS source code, user interface, project structure, documentation, and V5iOS branding authored for this project are reserved to Ali Tahseen.

This notice does not claim ownership of third-party libraries, APIs, trademarks, game files, or other third-party intellectual property. MoltenVK and other dependencies remain governed by their own licenses. Grand Theft Auto V, GTA V, Rockstar Games, and related names/assets belong to their respective owners and are not distributed with this project.
