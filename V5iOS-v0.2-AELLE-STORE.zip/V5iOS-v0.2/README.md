# V5iOS v0.2

Experimental iOS compatibility research launcher. This repository/project does **not** contain GTA V, Rockstar assets, DRM bypasses, or game executables.

## v0.2 milestone

- Retains the v0.1 device/Metal probe and GTA V data-folder scanner.
- Links the official Khronos **MoltenVK 1.4.2** iOS static XCFramework at build time.
- Adds a real Vulkan probe that:
  - enumerates Vulkan instance extensions;
  - creates a Vulkan instance;
  - enumerates the Apple GPU through MoltenVK;
  - reads Vulkan device/memory properties;
  - creates a logical device and graphics queue;
  - creates a command pool;
  - creates a small Vulkan test buffer.

A PASS proves the Vulkan -> MoltenVK -> Metal path is alive on the device. It does **not** prove GTA V can run; Android ARM64 ABI/runtime compatibility remains a separate research problem.

## Build

Use `.github/workflows/build-unsigned-ipa.yml`. It downloads MoltenVK v1.4.2 directly from the official KhronosGroup GitHub release and builds an unsigned IPA suitable for signing with your own certificate.


## Copyright

© 2026 Ali Tahseen. All rights reserved for the original V5iOS source code, interface, project structure, and branding authored for this project. Third-party components remain under their respective licenses. Rockstar Games / Take-Two assets and trademarks are not included and are not claimed.

## AELLE STORE
Built by **AELLE STORE**.

- Instagram: https://www.instagram.com/aellestore?stkn=MWFtc3o5eGQyZHhrYQ==
- Telegram: https://t.me/aellestore_bot
