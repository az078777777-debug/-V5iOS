import Foundation

struct VulkanProbeResult {
    let success: Bool
    let code: Int32
    let status: String
    let deviceName: String
    let apiVersion: String
    let physicalDeviceCount: UInt32
    let instanceExtensionCount: UInt32
    let deviceExtensionCount: UInt32
    let deviceLocalMemoryGB: Double
    let graphicsQueueFamily: Int32
}

enum VulkanProbe {
    static let moltenVKVersion = "1.4.2"

    static func run() -> VulkanProbeResult {
        let rawCode = V5VulkanRunProbe()
        let status = String(cString: V5VulkanStatus())
        let device = String(cString: V5VulkanDeviceName())
        let api = V5VulkanAPIVersion()

        let major = (api >> 22) & 0x3FF
        let minor = (api >> 12) & 0x3FF
        let patch = api & 0xFFF

        return VulkanProbeResult(
            success: rawCode == 0,
            code: rawCode,
            status: status,
            deviceName: device,
            apiVersion: "\(major).\(minor).\(patch)",
            physicalDeviceCount: V5VulkanPhysicalDeviceCount(),
            instanceExtensionCount: V5VulkanInstanceExtensionCount(),
            deviceExtensionCount: V5VulkanDeviceExtensionCount(),
            deviceLocalMemoryGB: Double(V5VulkanDeviceLocalMemoryBytes()) / 1_073_741_824.0,
            graphicsQueueFamily: V5VulkanGraphicsQueueFamily()
        )
    }
}
