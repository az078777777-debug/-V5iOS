#include "VulkanProbeBridge.h"
#include <vulkan/vulkan.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char gStatus[512] = "Not run yet.";
static char gDeviceName[VK_MAX_PHYSICAL_DEVICE_NAME_SIZE] = "Unknown";
static uint32_t gApiVersion = 0;
static uint32_t gPhysicalDeviceCount = 0;
static uint32_t gInstanceExtensionCount = 0;
static uint32_t gDeviceExtensionCount = 0;
static uint64_t gDeviceLocalMemoryBytes = 0;
static int32_t gGraphicsQueueFamily = -1;

static void setStatus(const char *text) {
    if (!text) text = "Unknown error";
    snprintf(gStatus, sizeof(gStatus), "%s", text);
}

static int hasExtension(const VkExtensionProperties *extensions, uint32_t count, const char *name) {
    for (uint32_t i = 0; i < count; i++) {
        if (strcmp(extensions[i].extensionName, name) == 0) return 1;
    }
    return 0;
}

int V5VulkanRunProbe(void) {
    setStatus("Starting Vulkan probe...");
    snprintf(gDeviceName, sizeof(gDeviceName), "%s", "Unknown");
    gApiVersion = 0;
    gPhysicalDeviceCount = 0;
    gInstanceExtensionCount = 0;
    gDeviceExtensionCount = 0;
    gDeviceLocalMemoryBytes = 0;
    gGraphicsQueueFamily = -1;

    uint32_t loaderVersion = VK_API_VERSION_1_0;
    PFN_vkEnumerateInstanceVersion pEnumerateInstanceVersion =
        (PFN_vkEnumerateInstanceVersion)vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion");
    if (pEnumerateInstanceVersion) {
        pEnumerateInstanceVersion(&loaderVersion);
    }

    uint32_t instanceExtCount = 0;
    VkResult result = vkEnumerateInstanceExtensionProperties(NULL, &instanceExtCount, NULL);
    if (result != VK_SUCCESS) {
        setStatus("vkEnumerateInstanceExtensionProperties(count) failed");
        return 10;
    }
    gInstanceExtensionCount = instanceExtCount;

    VkExtensionProperties *instanceExts = NULL;
    if (instanceExtCount > 0) {
        instanceExts = calloc(instanceExtCount, sizeof(VkExtensionProperties));
        if (!instanceExts) {
            setStatus("Out of memory while reading instance extensions");
            return 11;
        }
        result = vkEnumerateInstanceExtensionProperties(NULL, &instanceExtCount, instanceExts);
        if (result != VK_SUCCESS) {
            free(instanceExts);
            setStatus("vkEnumerateInstanceExtensionProperties(list) failed");
            return 12;
        }
    }

    const char *enabledInstanceExts[2];
    uint32_t enabledInstanceExtCount = 0;
    VkInstanceCreateFlags instanceFlags = 0;

#ifdef VK_KHR_PORTABILITY_ENUMERATION_EXTENSION_NAME
    if (instanceExts && hasExtension(instanceExts, instanceExtCount, VK_KHR_PORTABILITY_ENUMERATION_EXTENSION_NAME)) {
        enabledInstanceExts[enabledInstanceExtCount++] = VK_KHR_PORTABILITY_ENUMERATION_EXTENSION_NAME;
#ifdef VK_INSTANCE_CREATE_ENUMERATE_PORTABILITY_BIT_KHR
        instanceFlags |= VK_INSTANCE_CREATE_ENUMERATE_PORTABILITY_BIT_KHR;
#endif
    }
#endif

    VkApplicationInfo appInfo = {0};
    appInfo.sType = VK_STRUCTURE_TYPE_APPLICATION_INFO;
    appInfo.pApplicationName = "V5iOS Vulkan Probe";
    appInfo.applicationVersion = VK_MAKE_VERSION(0, 2, 0);
    appInfo.pEngineName = "V5iOS";
    appInfo.engineVersion = VK_MAKE_VERSION(0, 2, 0);
    appInfo.apiVersion = loaderVersion >= VK_API_VERSION_1_1 ? VK_API_VERSION_1_1 : VK_API_VERSION_1_0;

    VkInstanceCreateInfo instanceInfo = {0};
    instanceInfo.sType = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO;
    instanceInfo.flags = instanceFlags;
    instanceInfo.pApplicationInfo = &appInfo;
    instanceInfo.enabledExtensionCount = enabledInstanceExtCount;
    instanceInfo.ppEnabledExtensionNames = enabledInstanceExtCount ? enabledInstanceExts : NULL;

    VkInstance instance = VK_NULL_HANDLE;
    result = vkCreateInstance(&instanceInfo, NULL, &instance);
    free(instanceExts);
    if (result != VK_SUCCESS || instance == VK_NULL_HANDLE) {
        char buffer[160];
        snprintf(buffer, sizeof(buffer), "vkCreateInstance failed (%d)", (int)result);
        setStatus(buffer);
        return 20;
    }

    uint32_t physicalCount = 0;
    result = vkEnumeratePhysicalDevices(instance, &physicalCount, NULL);
    if (result != VK_SUCCESS || physicalCount == 0) {
        vkDestroyInstance(instance, NULL);
        setStatus("No Vulkan physical device was exposed by MoltenVK");
        return 30;
    }
    gPhysicalDeviceCount = physicalCount;

    VkPhysicalDevice *physicalDevices = calloc(physicalCount, sizeof(VkPhysicalDevice));
    if (!physicalDevices) {
        vkDestroyInstance(instance, NULL);
        setStatus("Out of memory while enumerating Vulkan devices");
        return 31;
    }
    result = vkEnumeratePhysicalDevices(instance, &physicalCount, physicalDevices);
    if (result != VK_SUCCESS) {
        free(physicalDevices);
        vkDestroyInstance(instance, NULL);
        setStatus("vkEnumeratePhysicalDevices(list) failed");
        return 32;
    }

    VkPhysicalDevice physicalDevice = physicalDevices[0];
    free(physicalDevices);

    VkPhysicalDeviceProperties props;
    memset(&props, 0, sizeof(props));
    vkGetPhysicalDeviceProperties(physicalDevice, &props);
    snprintf(gDeviceName, sizeof(gDeviceName), "%s", props.deviceName);
    gApiVersion = props.apiVersion;

    VkPhysicalDeviceMemoryProperties memProps;
    memset(&memProps, 0, sizeof(memProps));
    vkGetPhysicalDeviceMemoryProperties(physicalDevice, &memProps);
    for (uint32_t i = 0; i < memProps.memoryHeapCount; i++) {
        if (memProps.memoryHeaps[i].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) {
            gDeviceLocalMemoryBytes += memProps.memoryHeaps[i].size;
        }
    }

    uint32_t queueFamilyCount = 0;
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, NULL);
    if (queueFamilyCount == 0) {
        vkDestroyInstance(instance, NULL);
        setStatus("Vulkan device exposes no queue families");
        return 40;
    }

    VkQueueFamilyProperties *queueProps = calloc(queueFamilyCount, sizeof(VkQueueFamilyProperties));
    if (!queueProps) {
        vkDestroyInstance(instance, NULL);
        setStatus("Out of memory while reading queue families");
        return 41;
    }
    vkGetPhysicalDeviceQueueFamilyProperties(physicalDevice, &queueFamilyCount, queueProps);
    for (uint32_t i = 0; i < queueFamilyCount; i++) {
        if (queueProps[i].queueCount > 0 && (queueProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) {
            gGraphicsQueueFamily = (int32_t)i;
            break;
        }
    }
    free(queueProps);

    if (gGraphicsQueueFamily < 0) {
        vkDestroyInstance(instance, NULL);
        setStatus("No graphics-capable Vulkan queue family found");
        return 42;
    }

    uint32_t deviceExtCount = 0;
    result = vkEnumerateDeviceExtensionProperties(physicalDevice, NULL, &deviceExtCount, NULL);
    if (result != VK_SUCCESS) {
        vkDestroyInstance(instance, NULL);
        setStatus("vkEnumerateDeviceExtensionProperties(count) failed");
        return 50;
    }
    gDeviceExtensionCount = deviceExtCount;

    VkExtensionProperties *deviceExts = NULL;
    if (deviceExtCount > 0) {
        deviceExts = calloc(deviceExtCount, sizeof(VkExtensionProperties));
        if (!deviceExts) {
            vkDestroyInstance(instance, NULL);
            setStatus("Out of memory while reading device extensions");
            return 51;
        }
        result = vkEnumerateDeviceExtensionProperties(physicalDevice, NULL, &deviceExtCount, deviceExts);
        if (result != VK_SUCCESS) {
            free(deviceExts);
            vkDestroyInstance(instance, NULL);
            setStatus("vkEnumerateDeviceExtensionProperties(list) failed");
            return 52;
        }
    }

    const char *enabledDeviceExts[1];
    uint32_t enabledDeviceExtCount = 0;
#ifdef VK_KHR_PORTABILITY_SUBSET_EXTENSION_NAME
    if (deviceExts && hasExtension(deviceExts, deviceExtCount, VK_KHR_PORTABILITY_SUBSET_EXTENSION_NAME)) {
        enabledDeviceExts[enabledDeviceExtCount++] = VK_KHR_PORTABILITY_SUBSET_EXTENSION_NAME;
    }
#endif

    float priority = 1.0f;
    VkDeviceQueueCreateInfo queueInfo = {0};
    queueInfo.sType = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO;
    queueInfo.queueFamilyIndex = (uint32_t)gGraphicsQueueFamily;
    queueInfo.queueCount = 1;
    queueInfo.pQueuePriorities = &priority;

    VkDeviceCreateInfo deviceInfo = {0};
    deviceInfo.sType = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO;
    deviceInfo.queueCreateInfoCount = 1;
    deviceInfo.pQueueCreateInfos = &queueInfo;
    deviceInfo.enabledExtensionCount = enabledDeviceExtCount;
    deviceInfo.ppEnabledExtensionNames = enabledDeviceExtCount ? enabledDeviceExts : NULL;

    VkDevice device = VK_NULL_HANDLE;
    result = vkCreateDevice(physicalDevice, &deviceInfo, NULL, &device);
    free(deviceExts);
    if (result != VK_SUCCESS || device == VK_NULL_HANDLE) {
        vkDestroyInstance(instance, NULL);
        char buffer[160];
        snprintf(buffer, sizeof(buffer), "vkCreateDevice failed (%d)", (int)result);
        setStatus(buffer);
        return 60;
    }

    VkCommandPoolCreateInfo poolInfo = {0};
    poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
    poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
    poolInfo.queueFamilyIndex = (uint32_t)gGraphicsQueueFamily;

    VkCommandPool pool = VK_NULL_HANDLE;
    result = vkCreateCommandPool(device, &poolInfo, NULL, &pool);
    if (result != VK_SUCCESS) {
        vkDestroyDevice(device, NULL);
        vkDestroyInstance(instance, NULL);
        setStatus("Logical device works, but vkCreateCommandPool failed");
        return 70;
    }

    VkBufferCreateInfo bufferInfo = {0};
    bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
    bufferInfo.size = 4096;
    bufferInfo.usage = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT | VK_BUFFER_USAGE_TRANSFER_DST_BIT;
    bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;

    VkBuffer testBuffer = VK_NULL_HANDLE;
    result = vkCreateBuffer(device, &bufferInfo, NULL, &testBuffer);
    if (result != VK_SUCCESS) {
        vkDestroyCommandPool(device, pool, NULL);
        vkDestroyDevice(device, NULL);
        vkDestroyInstance(instance, NULL);
        setStatus("Vulkan device/queue works, but test buffer creation failed");
        return 80;
    }

    vkDestroyBuffer(device, testBuffer, NULL);
    vkDestroyCommandPool(device, pool, NULL);
    vkDeviceWaitIdle(device);
    vkDestroyDevice(device, NULL);
    vkDestroyInstance(instance, NULL);

    setStatus("PASS: MoltenVK created a Vulkan instance, GPU device, graphics queue, command pool and test buffer.");
    return 0;
}

const char *V5VulkanStatus(void) { return gStatus; }
const char *V5VulkanDeviceName(void) { return gDeviceName; }
uint32_t V5VulkanAPIVersion(void) { return gApiVersion; }
uint32_t V5VulkanPhysicalDeviceCount(void) { return gPhysicalDeviceCount; }
uint32_t V5VulkanInstanceExtensionCount(void) { return gInstanceExtensionCount; }
uint32_t V5VulkanDeviceExtensionCount(void) { return gDeviceExtensionCount; }
uint64_t V5VulkanDeviceLocalMemoryBytes(void) { return gDeviceLocalMemoryBytes; }
int32_t V5VulkanGraphicsQueueFamily(void) { return gGraphicsQueueFamily; }
