#ifndef VulkanProbeBridge_h
#define VulkanProbeBridge_h

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

int V5VulkanRunProbe(void);
const char *V5VulkanStatus(void);
const char *V5VulkanDeviceName(void);
uint32_t V5VulkanAPIVersion(void);
uint32_t V5VulkanPhysicalDeviceCount(void);
uint32_t V5VulkanInstanceExtensionCount(void);
uint32_t V5VulkanDeviceExtensionCount(void);
uint64_t V5VulkanDeviceLocalMemoryBytes(void);
int32_t V5VulkanGraphicsQueueFamily(void);

#ifdef __cplusplus
}
#endif

#endif
