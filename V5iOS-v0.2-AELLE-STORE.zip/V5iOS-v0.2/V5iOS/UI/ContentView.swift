import SwiftUI

struct ContentView: View {
    @State private var showFolderPicker = false
    @State private var scanResult: GameScanResult?
    @State private var vulkanResult: VulkanProbeResult?
    @State private var vulkanRunning = false
    private let report = DeviceProbe.current()

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    header
                    deviceCard
                    vulkanCard
                    gameDataCard
                    roadmapCard
                    copyrightFooter
                }
                .padding()
            }
            .navigationBarHidden(true)
        }
        .sheet(isPresented: $showFolderPicker) {
            FolderPicker { url in
                scanResult = GameFolderScanner.scan(url: url)
                showFolderPicker = false
            }
        }
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("V5iOS")
                .font(.system(size: 38, weight: .black, design: .rounded))
            Text("Experimental GTA V compatibility launcher for iOS")
                .foregroundColor(.secondary)
            Text("v0.2 • MoltenVK Vulkan Probe")
                .font(.caption.monospaced())
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var deviceCard: some View {
        card(title: "DEVICE PROBE") {
            row("Model", report.modelIdentifier)
            row("iOS", report.systemVersion)
            row("RAM", String(format: "%.2f GB", report.physicalMemoryGB))
            row("Metal", report.metalAvailable ? "Available" : "Unavailable")
            row("GPU", report.metalDeviceName)
            if let workingSet = report.recommendedMaxWorkingSetGB {
                row("GPU working set", String(format: "%.2f GB", workingSet))
            }
            row("Thermal", report.thermalState)
        }
    }

    private var vulkanCard: some View {
        card(title: "VULKAN / MOLTENVK") {
            row("MoltenVK", VulkanProbe.moltenVKVersion)

            Button {
                vulkanRunning = true
                vulkanResult = nil
                DispatchQueue.global(qos: .userInitiated).async {
                    let result = VulkanProbe.run()
                    DispatchQueue.main.async {
                        vulkanResult = result
                        vulkanRunning = false
                    }
                }
            } label: {
                HStack {
                    if vulkanRunning {
                        ProgressView()
                    } else {
                        Image(systemName: "bolt.horizontal.circle")
                    }
                    Text(vulkanRunning ? "Running Vulkan Probe..." : "Run Vulkan Probe")
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)
            .disabled(vulkanRunning)

            if let result = vulkanResult {
                Divider()
                HStack {
                    Image(systemName: result.success ? "checkmark.circle.fill" : "xmark.octagon.fill")
                    Text(result.success ? "VULKAN PASS" : "VULKAN FAIL (\(result.code))")
                        .font(.headline.monospaced())
                }
                row("Vulkan GPU", result.deviceName)
                row("Vulkan API", result.apiVersion)
                row("Physical devices", "\(result.physicalDeviceCount)")
                row("Instance extensions", "\(result.instanceExtensionCount)")
                row("Device extensions", "\(result.deviceExtensionCount)")
                row("Device-local memory", String(format: "%.2f GB", result.deviceLocalMemoryGB))
                row("Graphics queue", "\(result.graphicsQueueFamily)")
                Text(result.status)
                    .font(.caption.monospaced())
                    .foregroundColor(.secondary)
                    .textSelection(.enabled)
            } else {
                Text("This is a real Vulkan call path. The test creates a Vulkan instance, enumerates the Apple GPU through MoltenVK, creates a logical device and graphics queue, then creates a small Vulkan buffer.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
    }

    private var gameDataCard: some View {
        card(title: "GAME DATA") {
            Text("Choose a GTA V data folder that you legally own. V5iOS does not include or download Rockstar assets.")
                .font(.subheadline)
                .foregroundColor(.secondary)

            Button {
                showFolderPicker = true
            } label: {
                Label("Choose GTA V Folder", systemImage: "folder.badge.plus")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
            }
            .buttonStyle(.borderedProminent)

            if let result = scanResult {
                Divider()
                row("Folder", result.rootName)
                row("Accessible", result.accessible ? "Yes" : "No")
                row("Top-level items", "\(result.topLevelEntries)")
                row("Top-level file size", String(format: "%.2f GB", result.estimatedTopLevelSizeGB))
                row("Marker hits", "\(result.markerHits.count)/\(result.markerHits.count + result.missingMarkers.count)")

                if !result.markerHits.isEmpty {
                    Text("Found")
                        .font(.caption.bold())
                    ForEach(result.markerHits, id: \.self) { item in
                        Label(item, systemImage: "checkmark.circle.fill")
                            .font(.caption.monospaced())
                    }
                }

                if !result.notes.isEmpty {
                    ForEach(result.notes, id: \.self) { note in
                        Text(note)
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
        }
    }

    private var roadmapCard: some View {
        card(title: "NEXT ENGINEERING GATE") {
            Label("MoltenVK Vulkan probe — v0.2", systemImage: "checkmark.circle")
            Label("Render a Vulkan triangle to CAMetalLayer", systemImage: "2.circle.fill")
            Label("DXVK-native compatibility experiment", systemImage: "3.circle.fill")
            Label("Android ARM64 runtime ABI research", systemImage: "4.circle.fill")
            Text("A PASS here proves Vulkan commands can reach the A15 GPU through MoltenVK. It does not mean GTA V can run yet; runtime/ABI compatibility remains the hard part.")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }


    private var copyrightFooter: some View {
        VStack(spacing: 10) {
            Text("بواسطة AELLE STORE")
                .font(.headline.bold())

            HStack(spacing: 12) {
                Link(destination: URL(string: "https://www.instagram.com/aellestore?stkn=MWFtc3o5eGQyZHhrYQ==")!) {
                    Label("Instagram", systemImage: "camera")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                Link(destination: URL(string: "https://t.me/aellestore_bot")!) {
                    Label("Telegram", systemImage: "paperplane.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
            }

            Text("© 2026 Ali Tahseen")
                .font(.caption.bold())
            Text("All rights reserved • V5iOS")
                .font(.caption2.monospaced())
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .accessibilityElement(children: .contain)
    }

    private func card<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.caption.bold())
                .foregroundColor(.secondary)
            content()
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func row(_ key: String, _ value: String) -> some View {
        HStack(alignment: .top) {
            Text(key)
                .foregroundColor(.secondary)
            Spacer(minLength: 20)
            Text(value)
                .multilineTextAlignment(.trailing)
                .font(.system(.body, design: .monospaced))
        }
    }
}
